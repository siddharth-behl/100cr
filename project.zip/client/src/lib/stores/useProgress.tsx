import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { levelsData } from '../gameData';

interface ProgressState {
  // Level progression
  unlockedLevels: number[];
  completedLevels: number[];
  
  // Missions and skills
  completedMissions: string[];
  unlockedSkills: string[];
  
  // Level up modal
  showLevelUp: boolean;
  
  // Actions
  unlockLevel: (levelId: number) => void;
  completeLevel: (levelId: number) => void;
  toggleMission: (missionId: string) => void;
  unlockSkill: (skillId: string) => void;
  removeSkill: (skillId: string) => void;
  updateProgress: () => void;
  setShowLevelUp: (show: boolean) => void;
  
  // Reset progress (for testing)
  resetProgress: () => void;
}

export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      unlockedLevels: [1], // Start with first level unlocked
      completedLevels: [],
      completedMissions: [],
      unlockedSkills: [],
      showLevelUp: false,
      
      unlockLevel: (levelId) => {
        set((state) => {
          // Only add the level if it's not already unlocked
          if (!state.unlockedLevels.includes(levelId)) {
            return { 
              unlockedLevels: [...state.unlockedLevels, levelId].sort((a, b) => a - b)
            };
          }
          return {};
        });
      },
      
      completeLevel: (levelId) => {
        set((state) => {
          // Only add the level if it's not already completed
          if (!state.completedLevels.includes(levelId)) {
            // Unlock the next level if it exists
            const nextLevelId = levelId + 1;
            const nextLevelExists = levelsData.some(level => level.id === nextLevelId);
            
            if (nextLevelExists && !state.unlockedLevels.includes(nextLevelId)) {
              return {
                completedLevels: [...state.completedLevels, levelId].sort((a, b) => a - b),
                unlockedLevels: [...state.unlockedLevels, nextLevelId].sort((a, b) => a - b),
                showLevelUp: true
              };
            }
            
            return { 
              completedLevels: [...state.completedLevels, levelId].sort((a, b) => a - b),
              showLevelUp: true
            };
          }
          return {};
        });
      },
      
      toggleMission: (missionId) => {
        set((state) => {
          const isMissionCompleted = state.completedMissions.includes(missionId);
          
          if (isMissionCompleted) {
            // Remove from completed missions
            return {
              completedMissions: state.completedMissions.filter(id => id !== missionId)
            };
          } else {
            // Add to completed missions
            return {
              completedMissions: [...state.completedMissions, missionId]
            };
          }
        });
        
        // Update missions in level data
        get().updateProgress();
      },
      
      unlockSkill: (skillId) => {
        set((state) => {
          // Only add the skill if it's not already unlocked
          if (!state.unlockedSkills.includes(skillId)) {
            return { 
              unlockedSkills: [...state.unlockedSkills, skillId]
            };
          }
          return {};
        });
      },
      
      removeSkill: (skillId) => {
        set((state) => {
          // Only remove the skill if it's in the unlocked skills array
          if (state.unlockedSkills.includes(skillId)) {
            return {
              unlockedSkills: state.unlockedSkills.filter(id => id !== skillId)
            };
          }
          return {};
        });
      },
      
      updateProgress: () => {
        // Update the missions in the level data based on completed missions
        levelsData.forEach(level => {
          level.missions.forEach(mission => {
            const isMissionCompleted = get().completedMissions.includes(mission.id);
            mission.isCompleted = isMissionCompleted;
          });
          
          // Check if all required missions are completed
          const allRequiredMissionsCompleted = level.missions
            .filter(mission => !mission.isOptional)
            .every(mission => mission.isCompleted);
          
          // Auto-complete level if all required missions are done
          if (allRequiredMissionsCompleted && !get().completedLevels.includes(level.id)) {
            get().completeLevel(level.id);
          }
        });
      },
      
      setShowLevelUp: (show) => {
        set({ showLevelUp: show });
      },
      
      resetProgress: () => {
        set({
          unlockedLevels: [1],
          completedLevels: [],
          completedMissions: [],
          unlockedSkills: [],
          showLevelUp: false,
          unlockLevel: get().unlockLevel,
          completeLevel: get().completeLevel,
          toggleMission: get().toggleMission,
          unlockSkill: get().unlockSkill,
          removeSkill: get().removeSkill,
          updateProgress: get().updateProgress,
          setShowLevelUp: get().setShowLevelUp,
          resetProgress: get().resetProgress
        });
        
        // Reset mission completion status
        levelsData.forEach(level => {
          level.missions.forEach(mission => {
            mission.isCompleted = false;
          });
        });
      }
    }),
    {
      name: 'game-progress' // localStorage key
    }
  )
);
